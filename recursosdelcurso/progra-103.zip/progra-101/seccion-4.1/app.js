// Crear un algoritmo, que basado en la nota
// imprima si el alumno aprueba la materia
// aprueba 60
// si el alumno tiene nota menor 50
// imprimir un mensaje que diga:
// por favor estudie más


let nota = 40;


if (nota >= 60) {
    console.log('El alumno aprueba la clase');
} else if (nota < 50) {

    console.log('Por favor estudie más');
} else {
    console.log('El alumno NO aprueba la clase');
}


console.log('Fin del programa');