for (let i = 1; i <= 5; i++) {

    let reglon = '';

    for (let j = 1; j <= 5; j++) {
        reglon += `${ j * i }    `;
    }


    console.log(reglon)
}