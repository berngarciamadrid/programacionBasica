let km = 20;
let mi = km * 0.62;

console.log(mi);