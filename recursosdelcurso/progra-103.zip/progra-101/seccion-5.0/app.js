function sumar(a, b) {
    return a + b;
}


let total = sumar(10, 20);

console.log('Total: ' + total);