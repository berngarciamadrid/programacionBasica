// imprimir la tabla del 10
let base = 10;

// limite de la tabla
let limite = 5;


for (let i = 1; i <= limite; i++) {

    let resultado = base * i;

    console.log(base + ' x ' + i + ' = ' + resultado);

}